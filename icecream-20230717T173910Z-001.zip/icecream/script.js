let data = {
    Fruits: ["strawberry", "grapes", "banana", "apple"],
    liquid: ["water", "ice"],
    holder: ["cone", "cup", "stick"],
    toppings: ["chocolate", "peanuts"],
};

async function order() {
    const index = Math.floor(Math.random() * data.Fruits.length);
    const index2 =Math.floor(Math.random() * data.holder.length);

    try {
        setTimeout(() => {
            console.log(`Available ice-cream  ${data.Fruits}`)
            console.log(`choose your ice-cream`);},1000)

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`Your order is ${data.Fruits[index]} Flavor ice-cream`);
            resolve();
        }, 2000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log('Production started');
            resolve();
        }, 1000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`${data.Fruits[index]} has been chopped`);
            resolve();
        }, 2000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(` ${data.liquid[0]} and ${data.liquid[1]} added`);
            resolve();
        }, 2000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`process started...`);
            resolve();
        }, 1000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`ice-cream placed on ${data.holder[index2]}`);
            resolve();
        }, 2000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`${data.toppings[1]} as toppings`)
            resolve();
        }, 3000));

        await new Promise((resolve,reject) => 
            setTimeout(() => {
            console.log(`Ice-cream Served (.....------......)`);
            resolve();
        }, 1000));
    } catch (error) {
        console.log('Your order is cancelled', error);
    }
}

let store = true;
if (store) {
    console.log('Welcome to Naala Ice-Cream Store');
    order();
} else {
    console.log('Store is closed. Please visit again.');
}
